import csv,json,math,sys
from pathlib import Path
work=Path(sys.argv[1]);values=[float(r['value']) for r in csv.DictReader((work/'input.csv').open(encoding='utf-8-sig',newline=''))]
obj=json.loads((work/'output/result.json').read_text(encoding='utf-8-sig'))
if type(obj.get('count')) is not int or obj['count']!=len(values):raise SystemExit('FAIL count')
for key,expected in [('sum',sum(values)),('mean',sum(values)/len(values) if values else None)]:
 actual=obj.get(key)
 if expected is None:
  if actual is not None:raise SystemExit('FAIL mean')
 elif type(actual) not in (int,float) or not math.isfinite(actual) or not math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9):raise SystemExit('FAIL '+key)
print('PASS count/sum/mean')
