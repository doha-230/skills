import importlib.util,json,math,sys
from pathlib import Path
w=Path(sys.argv[1]);s=importlib.util.spec_from_file_location('candidate',w/'calc.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for values in json.loads((w/'cases.json').read_text(encoding='utf-8')):
 before=values[:];actual=m.total(values)
 if values!=before:raise SystemExit('FAIL input changed')
 if type(actual) not in (int,float) or not math.isfinite(actual) or not math.isclose(actual,sum(before),rel_tol=1e-9,abs_tol=1e-9):raise SystemExit('FAIL total')
print('PASS function cases')
