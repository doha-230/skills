import json,sys
from pathlib import Path
w=Path(sys.argv[1]);text=(w/'output/report.md').read_text(encoding='utf-8-sig')
for term in ['핵심 요약','주요 근거','확인 필요 사항']+json.loads((w/'expected_terms.json').read_text(encoding='utf-8')):
 if term not in text:raise SystemExit('FAIL missing: '+term)
if len(text.strip())<80:raise SystemExit('FAIL too short')
print('PASS structure/required terms; semantic quality needs manual review')
