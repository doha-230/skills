"""예제 프로필을 현재 압축 해제 경로에 맞는 settings.json으로 생성."""
import argparse,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--example',choices=['data','code','report']);p.add_argument('--provider');p.add_argument('--model');p.add_argument('--api-model');p.add_argument('--api-base',default='http://127.0.0.1:1234/v1');p.add_argument('--output',default='settings.json');p.add_argument('--force',action='store_true')
a=p.parse_args()
def ask(value,label,default=None):
 if value:return value
 text=input(label+(' ['+default+']' if default else '')+': ').strip()
 if not text and default:return default
 if not text:raise SystemExit('필수 값이 비어 있습니다: '+label)
 return text
example=ask(a.example,'예제 선택 data / code / report','data')
if example not in ('data','code','report'):raise SystemExit('지원하지 않는 예제')
provider=ask(a.provider,'Pi provider 이름');model=ask(a.model,'Pi 모델 ID');api_model=ask(a.api_model,'개선 API 모델 ID',model)
if any(x=='CHANGE_ME' for x in (provider,model,api_model)):raise SystemExit('실제 모델/공급자 값을 입력하세요.')
out=Path(a.output);out=out if out.is_absolute() else ROOT/out
if out.exists() and not a.force:raise SystemExit('이미 존재합니다. 다른 --output을 지정하거나 --force를 사용하세요: '+str(out))
v=json.loads((ROOT/'profiles'/f'{example}.json').read_text(encoding='utf-8'))
c=v['CONFIG'];c.update(pi_provider=provider,pi_model=model,optimizer_model=api_model,api_base=a.api_base,pi_command=['pi.cmd' if os.name=='nt' else 'pi'])
for key in ('skill_path','output_dir'):c[key]=str((ROOT/c[key]).resolve())
for task in v['TASKS']:
 task['seed_dir']=str((ROOT/task['seed_dir']).resolve())
 for check in task['checks']:check['argv']=[x.replace('{package}',str(ROOT).replace('\\','/')) for x in check['argv']]
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('설정 생성:',out)
print('다음: python pi_skill_harness.py doctor --config "'+str(out)+'"')
