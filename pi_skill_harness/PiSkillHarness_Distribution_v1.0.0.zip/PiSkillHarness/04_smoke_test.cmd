@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
python smoke_test.py
set "HARNESS_EXIT=%ERRORLEVEL%"
echo Exit code: %HARNESS_EXIT%
pause
popd
exit /b %HARNESS_EXIT%
