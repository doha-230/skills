import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;manifest=json.loads((r/'MANIFEST.json').read_text(encoding='utf-8'));bad=[]
for rel,sha in manifest['sha256'].items():
 p=r/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:bad.append(rel)
if bad:raise SystemExit('변경/누락 파일: '+', '.join(bad))
print('PASS: 배포 원본 파일 해시 일치 (사용자 생성 settings/runs 제외)')
