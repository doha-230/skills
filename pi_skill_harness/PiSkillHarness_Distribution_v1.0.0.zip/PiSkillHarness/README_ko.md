# Pi Skill Harness · 배포 예제 세트 1.0.0

처음에는 START_HERE.html을 브라우저로 여세요. 인터넷 없이 읽을 수 있습니다.

## 준비
- Python 3.10 이상, 설치되어 정상 동작하는 Pi, 로컬 LLM 서버가 필요합니다.
- 하네스 및 포함 예제는 Python 표준 라이브러리만 사용합니다.
- Pi·Node·모델은 ZIP에 포함되어 있지 않습니다. 자동 설치나 다운로드를 수행하지 않습니다.
- 이 폴더를 예: C:/PiHarness 에 압축 해제하세요. 경로에 한글/공백이 있어도 경로를 따옴표로 감싸 사용하세요.

## 첫 실행
1. `03_selftest.cmd`로 자체 검사와 예제 검사기를 확인합니다. Pi·LLM 연결 없이 실행됩니다.
2. `00_setup.cmd`에서 data / code / report를 선택하고 실제 모델 정보를 입력합니다.
3. 생성된 settings.json의 api_base를 실제 API 주소로 확인합니다. 기본은 http://127.0.0.1:1234/v1 입니다.
4. `01_check.cmd`로 설정과 Pi 옵션을 확인합니다. API 실제 연결 검사는 아닙니다.
5. `02_run.cmd`로 실행합니다. 기본 예제 하나는 최대 32회 Pi 실행입니다.
6. runs/예제명/실험폴더/final_decision.json을 확인합니다. 후보가 없으면 원본이 유지됩니다.

명령행으로 설정하는 경우:
```powershell
python configure.py --example data --provider LOCAL_PROVIDER --model PI_MODEL_ID --api-model API_MODEL_ID --api-base http://127.0.0.1:1234/v1
python pi_skill_harness.py doctor --config settings.json
python pi_skill_harness.py run --config settings.json
```

기존 settings.json이 있으면 configure.py는 덮어쓰지 않습니다. `--output settings_code.json`으로 다른 이름을 쓰거나, 덮어쓸 때만 `--force`를 붙이세요. 패키지 위치를 옮긴 뒤에는 절대 경로가 바뀌므로 설정을 다시 생성하세요.

## 예제 3종
- data: CSV 집계 → JSON. 보조 스크립트 사용, 독립 검사기로 count/sum/mean 검증, checks_only.
- code: 기존 calc.py 수정. 변경 허용 결과와 보존 입력을 분리, 함수 결과 및 입력 변경 여부 검사, checks_only.
- report: 한글 Markdown 보고서. 제목·필수 수치 검사 후 실제 의미 품질은 manual.

각 예제에 서로 다른 train/holdout 입력이 있습니다. 예제는 하네스 사용법을 보여주는 작은 작업이며 최적화 효과를 보장하지 않습니다. 실제 평가에는 여러 대표 업무와 충분한 독립 검증 자료가 필요합니다.

## 수동 승인
report 예제 등에서 pending_manual_review이면 review.html과 실제 출력 파일을 확인하세요.
```powershell
python pi_skill_harness.py approve "C:/PiHarness/runs/report/실제실험폴더" --confirm-reviewed
```
승인해도 원본 스킬은 바뀌지 않으며 결과 폴더의 best_SKILL.md만 갱신됩니다. 승인 기록은 approval.json에 저장됩니다.

## 내 업무로 바꾸기
생성된 settings.json에서 skill_path, TASKS의 prompt/seed_dir/artifacts/checks/quality_mode/quality_rules를 수정하세요. 이 패키지의 profiles/*.json은 configure.py용 템플릿입니다. {package}와 상대 경로가 있으므로 하네스에 직접 넘기지 마세요.

## 로그와 제한
- 현재 Pi 프로세스 전체 시간 측정. 검증/복사/모델 개선 시간은 별도입니다.
- 기존 Pi의 전역 스킬·확장·AGENTS.md를 기본으로 상속하지 않습니다.
- 작업폴더 분리는 OS 샌드박스가 아닙니다. 로컬 사용자 권한으로 실행합니다.
- 입력·결과·기록이 여러 번 복사되므로 디스크 공간을 확보하세요.
- 자체 검사 및 모의 CLI 흐름 검증과 실제 Pi/LLM 연결 검증은 별개입니다.

자세한 설정과 오류 해결: docs/manual_ko.html
배포 파일 무결성: python verify_package.py

## 범용 빈 설정과 추가 점검
- templates/settings.generic.json: 실제 업무로 교체할 범용 설정 템플릿. tasks_confirmed=false입니다.
- 04_smoke_test.cmd: 모의 CLI로 전체 반복 흐름을 검사합니다. 실제 Pi/LLM을 호출하지 않으며 속도는 합성값입니다.
