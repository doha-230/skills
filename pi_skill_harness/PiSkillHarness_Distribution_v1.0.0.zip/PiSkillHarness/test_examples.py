"""Pi/LLM 없이 예제 검증기의 통과·실패 동작을 검사합니다. 성능 측정 아님."""
import json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
count=0
for kind in ('data','code','report'):
 for split in ('train','holdout'):
  with tempfile.TemporaryDirectory() as d:
   work=Path(d)/'work';shutil.copytree(ROOT/'examples'/kind/'inputs'/split,work)
   (work/'output').mkdir(exist_ok=True)
   if kind=='data':
    subprocess.run([sys.executable,str(ROOT/'examples/data/skill/scripts/summarize.py'),'input.csv','output/result.json'],cwd=work,check=True)
   elif kind=='code':
    (work/'calc.py').write_text('def total(values):\n    return sum(values)\n',encoding='utf-8')
   else:
    text='# 핵심 요약\n'+(work/'source.txt').read_text(encoding='utf-8')+'\n# 주요 근거\n입력 자료의 수치를 기준으로 정리하였다.\n# 확인 필요 사항\n추가 검증이 필요하다.\n'
    (work/'output/report.md').write_text(text,encoding='utf-8')
   cmd=[sys.executable,str(ROOT/'validators'/f'check_{kind}.py'),str(work)]
   result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
   if result.returncode:raise SystemExit('정상 결과 탈락: '+result.stdout+result.stderr)
   target=work/('calc.py' if kind=='code' else 'output/result.json' if kind=='data' else 'output/report.md')
   target.write_text('def total(values):\n    return -999999\n' if kind=='code' else '{"count":999}' if kind=='data' else '누락된 보고서',encoding='utf-8')
   # 같은 크기/같은 타임스탬프의 pyc 재사용 방지
   shutil.rmtree(work/'__pycache__',ignore_errors=True)
   bad=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
   if bad.returncode==0:raise SystemExit('오류 결과를 통과시킴: '+kind)
   count+=2
print(f'PASS: {count} example validator cases. No Pi/LLM calls.')
