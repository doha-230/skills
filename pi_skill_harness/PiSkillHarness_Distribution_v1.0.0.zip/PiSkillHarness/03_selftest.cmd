@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
python pi_skill_harness.py selftest
if errorlevel 1 goto done
python test_examples.py
:done
set "HARNESS_EXIT=%ERRORLEVEL%"
echo.
echo Exit code: %HARNESS_EXIT%
pause
popd
exit /b %HARNESS_EXIT%
