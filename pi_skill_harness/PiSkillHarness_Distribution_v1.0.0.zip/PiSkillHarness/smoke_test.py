"""모의 CLI로 하네스 전체 흐름 검사. 실제 LLM 또는 성능 시험이 아닙니다."""
import contextlib,importlib.util,io,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('harness_test',ROOT/'pi_skill_harness.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
with tempfile.TemporaryDirectory(prefix='pi harness smoke ') as temp:
 r=Path(temp)
 cfg=r/'settings.json'
 subprocess.run([sys.executable,str(ROOT/'configure.py'),'--example','data','--provider','mock','--model','mock','--api-model','mock','--output',str(cfg)],check=True,capture_output=True)
 h.apply_config(str(cfg))
 fake=r/'fake_pi.py'
 fake.write_text('''import csv,json,sys
from pathlib import Path
if '--help' in sys.argv:
 print('--no-session --skill --no-skills --no-context-files --no-extensions --no-prompt-templates --thinking');raise SystemExit()
values=[float(row['value']) for row in csv.DictReader(Path('input.csv').open(encoding='utf-8-sig',newline=''))]
Path('output').mkdir(exist_ok=True)
Path('output/result.json').write_text(json.dumps({'count':len(values),'sum':sum(values),'mean':sum(values)/len(values) if values else None}),encoding='utf-8')
''',encoding='utf-8')
 h.CONFIG.update(output_dir=str(r/'runs'),pi_command=[sys.executable,str(fake)],pi_agent_template=str(r/'no_private_config'))
 h.propose=lambda current,original,feedback,tasks:(current+'\n중복 읽기는 줄이고 필수 검증은 유지한다.\n','mock hypothesis')
 original_run=h.run_one
 def simulated_timing(*args):
  row=original_run(*args)
  # 시간 선택 경로를 결정적으로 검사하는 합성값. 실측 개선율 아님.
  row['seconds']=100.0 if row['label']=='reference' else 70.0
  return row
 h.run_one=simulated_timing
 with contextlib.redirect_stdout(io.StringIO()):h.run()
 out=next((r/'runs').iterdir());decision=h.read_json(out/'final_decision.json')
 if decision['status']!='accepted':raise SystemExit('FAIL selection: '+str(decision))
 if (out/'best_SKILL.md').read_bytes()!=(out/'candidate_SKILL.md').read_bytes():raise SystemExit('FAIL promotion')
 if list(out.rglob('private_agent')):raise SystemExit('FAIL private config cleanup')
 print('PASS: configure paths, fake CLI, validators, randomized pairs, holdout, final selection, resource copies and config cleanup')
 print('NOTE: timings were synthetic; no real Pi/LLM or Windows .cmd integration was tested.')
