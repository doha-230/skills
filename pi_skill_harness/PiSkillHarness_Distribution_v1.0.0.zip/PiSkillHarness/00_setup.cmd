@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
python configure.py
:done
set "HARNESS_EXIT=%ERRORLEVEL%"
echo.
echo Exit code: %HARNESS_EXIT%
pause
popd
exit /b %HARNESS_EXIT%
