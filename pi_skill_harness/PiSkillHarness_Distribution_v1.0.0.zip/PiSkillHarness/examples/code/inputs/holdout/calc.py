def total(values):
    return len(values)  # TODO: 요구사항에 맞게 수정
