import csv,json,sys
from pathlib import Path
rows=list(csv.DictReader(Path(sys.argv[1]).open(encoding='utf-8-sig',newline='')))
values=[float(r['value']) for r in rows]
result={'count':len(values),'sum':sum(values),'mean':sum(values)/len(values) if values else None}
out=Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
