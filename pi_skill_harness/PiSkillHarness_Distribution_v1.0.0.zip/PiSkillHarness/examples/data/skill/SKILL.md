---
name: csv-summary
description: CSV의 수치 열을 읽어 정확한 합계와 평균을 JSON으로 저장한다.
---
# CSV 요약
1. task.txt를 읽고 입력 파일과 출력 형식을 확인한다.
2. 입력 CSV의 헤더와 행을 확인한다.
3. 이 스킬의 scripts/summarize.py를 사용한다. 스크립트 경로는 이 SKILL.md 기준 상대 경로이다.
4. python "스킬폴더/scripts/summarize.py" input.csv output/result.json 형태로 실행한다.
5. 생성한 JSON을 읽고 행 수, 합계, 평균을 입력과 대조한다.
6. 값은 반올림하지 않고 저장하며 빈 입력 평균은 null로 표시한다.
