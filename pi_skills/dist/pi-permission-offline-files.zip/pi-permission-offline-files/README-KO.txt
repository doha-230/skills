Pi 권한 자동 심사 확장 — 폐쇄망 반입 파일

포함 버전
- @mzwing/pi-permission-auto-review 0.9.2 (공식 npm 배포본)
- @gotgenes/pi-permission-system 41.0.0 (공식 npm 배포본)
- zod 4.6.7
- web-tree-sitter 0.26.13
- tree-sitter-bash 0.25.1 (WASM 포함)
- node-addon-api 8.9.2, node-gyp-build 4.8.4

구성
- 설정설명서.html: 인터넷 없이 열 수 있는 Windows·Strata 설정 안내
- node_modules/: 위 패키지와 실행 의존성이 이미 풀려 있는 폴더
- package.json: 두 공식 확장의 진입점을 지정하는 로컬 Pi 패키지 메타데이터
- package-lock.json: 정확한 패키지 버전과 공식 배포본 무결성 정보
- SHA256SUMS.txt: 압축 내 개별 파일의 SHA-256
- 공식 README, LICENSE, 스키마, 예시 설정은 해당 패키지 폴더에 포함

전제
- 대상 PC에 Node.js 24 이상, Pi 1.3.0 이상이 설치되어 있어야 합니다.
- 이 배포본의 Pi 의존성 이름은 @earendil-works/pi-* 입니다.
  이전 @mariozechner/pi-* 기반 Pi/OMP와의 호환성은 보장하지 않습니다.
- Pi/Node.js 자체 및 LLM 모델 가중치는 포함하지 않았습니다.
- 설치된 Pi가 제공하는 peerDependencies는 중복으로 넣지 않았습니다.
- 기본 심사 모델은 온라인 openai-codex/codex-auto-review입니다.
  폐쇄망에서는 Pi에 등록한 로컬 provider/model을 사용자가 지정해야 합니다.
  로컬 모델의 심사 정확도는 Codex 전용 심사 모델과 같다고 보장되지 않습니다.

사용자 설정 파일(config.json), 모델 등록 파일, 설치/복사 스크립트는 없습니다.
원본에 포함된 config.example.json은 참고용 예시이며 활성 설정이 아닙니다.
폴더 배치, 확장 등록, authorizerChain 및 모델 설정은 사용자가 직접 수행합니다.
node_modules를 포함한 폴더 구조를 유지해야 패키지 간 의존성이 해결됩니다.
package-lock.json의 registry URL은 출처 정보이며, 포함된 의존성 실행에 다운로드가
필요하다는 뜻은 아닙니다. 대상 PC에서 npm install을 다시 할 필요는 없습니다.
권한 시스템 확장을 이미 등록했다면 중복 로딩하지 않도록 사용자가 조정해야 합니다.

검증
- 두 공식 확장 파일을 npm 원본 tarball과 바이트 대조
- 심사 공개 모듈 로딩 및 내장 정책 생성
- allow 판정 JSON 파싱
- 로컬 WASM 두 파일 로딩과 Bash 구문 분석
- ZIP 무결성 확인
Windows에서 실제 Pi 세션 로딩 및 로컬 LLM 연결 검증은 수행하지 않았습니다.

출처
https://github.com/mzwing/pi-packages/tree/master/packages/pi-permission-auto-review
https://www.npmjs.com/package/@mzwing/pi-permission-auto-review
https://www.npmjs.com/package/@gotgenes/pi-permission-system
